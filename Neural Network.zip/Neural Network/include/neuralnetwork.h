#ifndef NEYRO_NEURALNETWORK_H
#define NEYRO_NEURALNETWORK_H

#include "data.h"
#include <fstream>
#include <vector>

class Neuralnetwork {
    Norm params;
    std::vector<int> layers;
    std::vector<std::vector<std::vector<double>>> w;
    std::vector<std::vector<double>> b;
    std::vector<std::vector<double>> a;
    std::vector<std::vector<double>> f;
    std::vector<std::vector<double>> delta;
    double lr;

public:
    Neuralnetwork(const std::vector<int> &inner_size, double learning_rate);
    void set_norm(const Norm &p);
    void weights();
    double forward(double x, double y);
    void tofile(const std::vector<Point> &data, std::ofstream &file);
    void backward(int truelabel);
    void train_epoch(std::vector<Point> &traindata);
    void update();
    int predict(Point &p);
    double evaluate(const std::vector<Point> &data);
};

#endif
